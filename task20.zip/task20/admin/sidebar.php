<div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="active"><a href="overview.php">Overview <span class="sr-only">(current)</span></a></li>
             <li><a href="dashboard.php">Dashboard</a></li>
             <li><a href="view_all_user.php">View all User </a></li>
             <li><a href="add_product.php">Add Product</a></li>
             <li><a href="logout.php">Logout</a></li>
          </ul>
         </div>
        