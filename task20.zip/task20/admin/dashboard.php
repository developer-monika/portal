<?php 
include 'header.php';
include '../user_header.php';
?>
<?php include '../db.php';?>
<?php
     if(!isset ($_SESSION['is_admin_logged_in']))
     {
      header("location:../index.php");
     }
?>
<div class="container-fluid">
      <div class="row">
        <?php include('sidebar.php');?>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
         <h2>Welcome to admin...</h2>
         <h2 class="sub-header">Hello admin !!!>
         </h2>
       
        </div>
      </div>
    </div>
     <?php include '../footer.php';?>
    
  
   

    
  </body>
</html>