<?php 
include 'header.php';
include '../user_header.php';
?>
<?php
include("../db.php");
if(! isset($_SESSION['is_admin_logged_in']))
{
  header("location:../index.php");
}
$que="SELECT * FROM info_tbl";
$obj=mysql_query($que);
?>
<?php
  if (isset($_POST['submit'])) {
    
    // extract($_POST);
    $pName = $_POST['pName'];
    $pDetail = $_POST['pDetail'];
    $pPrice = $_POST['pPrice'];
    $source=$_FILES['img']['tmp_name']; 
    $destination="image/".$_FILES['img']['name'];
    $upload=$_FILES['img']['name'];

    move_uploaded_file($source, $destination);
    // query for product insert in db
    $insertProduct = "INSERT INTO `product_tbl` (`product_name`,`product_detail`,`product_price`,`product_image`) VALUES ('$pName','$pDetail','$pPrice','$upload')";

    $query = mysql_query($insertProduct);
         
      if ($query) {
        header("Location:../index.php");
      }else{
        echo "insert Error";
      }

  }

?>

<div class="container-fluid">
      <div class="row">
        <?php include('sidebar.php');?> 
         <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
         <h2 class="sub-header">Product!!!</h2>
         <form method="post" enctype="multipart/form-data" action="">
         <div class="form-group">
        <label class="form-label">Product Name</label>
        <input class="form-conrole" type="text" placeholder="Product Name" name="pName" required><br>
        </div>
        <label>Product Detail</label>
        <textarea placeholder="Product Detail" name="pDetail" required></textarea><br>
        <label>Product price</label>
        <input type="text" placeholder="Product price" name="pPrice" required><br>
        <label>Product Image</label>
        <input type="file" name="img" ><br>
        <button type="submit" name="submit">AddProduct</button>
        </div>
    </form>

        </div>
      </div>
    </div>
     <?php include '../footer.php';?>
    
  
   

    
  </body>
</html>