<?php
include("db.php");
$a = $_POST['username'];
$b = $_POST['password'];
$b=md5($b);
$c = $_POST['address'];
$d = $_POST['city'];
$e = $_POST['gender'];
$que="INSERT INTO info_tbl (username,password,address,city,gender) 
          VALUES ('$a', '$b','$c','$d','$e')";
mysql_query($que);
header("location:login.php");
?>
	
