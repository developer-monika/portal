<?php 
include 'db.php';
if (! isset ( $_SESSION ['is_user_logged_in'] ))
{
    header('location:login.php');
}
include("user_header.php");

$que ="SELECT * FROM info_tbl WHERE id= ".$_SESSION ['id'];
$obj= mysql_query($que);
$data= mysql_fetch_assoc($obj);
?>

<div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <?php include 'sidebar.php'; ?>
         </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
           <h2 class="sub-header">View User Profile</h2>
          <div class="table-responsive">
          
            <table class="table table-striped">
             <tbody>
               <tr>
                  <th>Username</th>
                  <td><?php echo $data ['username']?></td>
                 
                </tr>
                <tr>
                 <th>Address</th>
                 <td><?php echo $data ['address']?></td>
                 
                </tr>
                <tr>
                 <th>city</th>
                  <td><?php echo $data ['city']?></td>
                 
                </tr>
                <tr>
                  <th>Gender</th>
                 <td><?php echo $data ['gender']?></td>
                  
                </tr>
                
               
               
              </tbody>
            </table>
            
          </div>
        </div>
      </div>
    </div>
     <?php include 'footer.php';?>
    
  
   

    
  </body>
</html>