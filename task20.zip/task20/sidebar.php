<ul class="nav nav-sidebar">
            <li class="active"><a href="overview.php">Overview <span class="sr-only">(current)</span></a></li>
             <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="user_profile.php">My Profile</a></li>
            <li><a href="edit_profile.php">Edit Profile</a></li>
            <li><a href="change_pass.php">Change Password</a></li>
           <li><a href="login.php">Logout</a></li>
          </ul>