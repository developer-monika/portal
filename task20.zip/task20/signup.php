<?php include 'header.php';?>
<script type="text/javascript"></script>
    <div class="container">
	<br/><br/><br/><br/><br/>
    <!-- Main form -->
   <div class="container">
            <form class="form-horizontal" role="form" id="formID" action="info_save.php" method="post">
                <h2>Registration Form</h2>
                <div class="form-group">
                    <label for="Username" class="col-sm-3 control-label">Username</label>
                    <div class="col-sm-9">
                        <input type="email" id="username" name="username" placeholder="Username" class="form-control validate[required]">
                       <!--  <p class="error" id="username_msg"></p> -->
                    </div>
                </div>
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                        <input type="password" id="password" name="password" placeholder="Password" class="form-control validate[required]">
                       <!--  <p class="error">Error</p> -->
                    </div>
                </div>
				 <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Confirm  password </label>
                    <div class="col-sm-9">
                        <input type="password" id="repass" name="repass" placeholder="Confirm  password" class="form-control validate[required]">
                        <!-- <p class="error" id="repass">Error</p> -->
                    </div>
                </div>
                <div class="form-group">
                    <label for="Address" class="col-sm-3 control-label">Address</label>
                    <div class="col-sm-9">
                        <textarea cols="45" rows="5" name="address" placeholder="Entar Your Address Here "></textarea>
                       <!--  <p class="error">Error</p> -->
                    </div>
                </div>

                <div class="form-group">
                    <label for="City" class="col-sm-3 control-label">City</label>
                    <div class="col-sm-9">
                        <select id="" name="city" class="form-control validate[required]">
                             <option>Mumbai</option>
                            <option>Indore</option>
                            <option>Delhi</option>
                            <option>Chennai</option>
                            <option>Bhopal</option>
                        </select>
                        <!-- <p class="error">Error</p> -->
                    </div>
                </div> <!-- /.form-group -->
                <div class="form-group">
                    <label class="control-label col-sm-3">Gender</label>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" id="" name="gender" value="Female">Female
                                </label>
                            </div>
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" id="" name="gender" value="Male">Male
                                </label>
                            </div>
                        </div>
                       <!--   <p class="error">Error</p> -->
                    </div>

                </div> <!-- /.form-group -->
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" name="submit" class="btn btn-primary btn-block">Add</button>
                    </div>
                </div>
            </form> <!-- /form -->
        </div> <!-- ./container -->
 </div> <!-- /container -->
    
      <hr>
   <?php include 'footer.php';?>
    
<!-- <style type="text/css">
    .error{
        color: red;
    }
</style>	
   <script type="text/javascript">
    $(document).ready(function(){
        $("[type='submit']").click(function(){
            var a=$("#username").val();
            var b=$("#password").val();
            var c=$("#repassword").val();
            var d=$("#address").val();
            var e=$("#city").val();
            var f=$("#gender").val();
            var check=true;
            // var focus="";
            if(h==false && i==false)
            {
                $("#gender_msg").html("Select Gender");
                // focus="#full_name_msg";
                check=false;
            }
            else
            {
                $("#gender_msg").html("");

            }

            
            if(b=="")
            {
                $("#username_msg").html("Insert Your Username");
                // focus="#email_msg";
                check=false;
            }
            else
            {
                $("#username_msg").html("");
                var reg=/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/; 
                if(reg.test(b)==false)
                {
                    $("#username_msg").html("Insert Correct Email");
                    check=false;
                }
                else
                {
                    $("#username_msg").html("");

                }
            }
            if(c=="")
            {
                $("#pass_msg").html("Insert Your Password");
                // $("#pass").focus();
                check=false;
            }
            else
            {
                $("#pass_msg").html("");
                if(c != d)
                {
                    $("#re_pass_msg").html("Correct Your Re-Password");
                    check=false;
                }
                else
                {
                    
                    $("#re_pass_msg").html("");
                }
            }
            if(f=="Select")
            {
                $("#city_msg").html("Select Your City");
                check=false;
            }
            else
            {
                $("#city_msg").html("");

            }

            if(check==false)
            {
                $("#pass").val("");
                $("#re_pass").val("");
            }

            return check;

        });
    });
</script> -->

    
  </body>
</html>