<?php include 'header.php';
include 'db.php';
if (! isset ( $_SESSION ['is_user_logged_in'] ))
{
    header('location:login.php');
}
include("user_header.php");

$que ="SELECT * FROM info_tbl WHERE id= ".$_SESSION ['id'];
$obj= mysql_query($que);
$data= mysql_fetch_assoc($obj);
?>

<div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <?php include 'sidebar.php'; ?>
         </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
           <h2 class="sub-header">Update User Profile</h2>
          <div class="table-responsive">
          
      <form class="form-horizontal" role="form" action="update_profile.php" method="post">
       <br/>
       
               <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Username</label>
                    <div class="col-sm-9">
                        <input type="email" id="" name="username" placeholder="Username" class="form-control"
                         value="<?php echo $data['username'];?>" 
                         disabled="disabled" />
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Address</label>
                    <div class="col-sm-9">
                        <input type="text" id="" name="address" placeholder="" class="form-control"
                    value="<?php echo $data['address'];?>"
                          />    
                    </div>
                </div>
                <div class="form-group">
                    <label for="country" class="col-sm-3 control-label">City</label>
                    <div class="col-sm-9">
                        <select id="" name="city" class="form-control">
                        <option <?php if ($data['city']=="Mumbai") {
                          echo "selected= 'selected'";
                        }?>>Mumbai</option>
                            <option><?php if ($data['city']=="Indore") {
                          echo "selected= 'selected'";
                        }?>Indore</option>
                            <option><?php if ($data['city']=="Delhi") {
                          echo "selected= 'selected'";
                        }?>Delhi</option>
                        <!--     <option><?php if ($data['city']=="Chennai") {
                          echo "selected= 'selected'";
                        }?>Chennai</option> -->
                            <option><?php if ($data['city']=="Bhopal") {
                          echo "selected= 'selected'";
                        }?>Bhopal</option>
                        </select>
                    </div>
                </div> <!-- /.form-group -->
                <div class="form-group">
                    <label class="control-label col-sm-3">Gender</label>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                <input type="radio" id="" name="gender" value="Female" 
                                <?php if ($data['gender']=='Female') 
                                {
                                    echo "checked='checked'";
                                } ?>>Female
                                </label>
                            </div>
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                <input type="radio" id="" name="gender" value="Male"
                                    <?php if ($data['gender']=='Male') 
                                {
                                    echo "checked='checked'";
                                } ?>>Male
                                </label>
                            </div>
                        </div>
                    </div>
                </div> <!-- /.form-group -->
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" name="submit" class="btn btn-primary btn-block">Update</button>
                    </div>
                </div>
            </form> <!-- /form -->
         
            
          </div>

        </div>
      </div>
    </div>
     <?php include 'footer.php';?>
    
  
   

    
  </body>
</html>