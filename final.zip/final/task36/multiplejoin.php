<?php 
$conn = mysqli_connect("localhost", "root", "", "multijoin");
$sql = "Select  usertype.user_type,company.company_name,usertbl.name from usertbl JOIN company ON
		usertbl.company_id=company.id
	JOIN usertype ON
		usertbl.usertype=usertype.id where usertbl.id=1";
$result = mysqli_query($conn,$sql);
$user=mysqli_fetch_assoc($result);
echo '<pre>';print_r($user);





 ?>