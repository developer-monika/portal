<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>Sign up successfully</h1>
</body>
</html>