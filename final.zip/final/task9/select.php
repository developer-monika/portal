<?php
include('connect.php');

if (isset($_POST['state'])) {
	$stt = $_POST['state'];
	$query = "SELECT `state` FROM `state`";
	$result = mysqli_query($conn,$query);
	$i=0;
	while ($row = mysqli_fetch_array($result)){
		// if ($row['state'] != $stt) {
			$state[$i] = $row['state'];
			$i++;
		// }		
	}
	print_r(json_encode($state));
}
if (isset($_POST['state1'])) {
	$stt1 = $_POST['state1'];
	$query1 = "SELECT `state` FROM `state`";
	$result1 = mysqli_query($conn,$query1);
	$i=0;
	while ($row1 = mysqli_fetch_array($result1)){
		// if ($row1['state'] != $stt1[0] && $row1['state'] != $stt1[1]) {
			$state1[$i] = $row1['state'];
			$i++;
		// }		
	}
	print_r(json_encode($state1));
}
?>