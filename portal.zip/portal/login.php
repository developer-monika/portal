<?php 
include  'db.php';
include 'header.php';
?>
    

    <div class="container">
      <br/><br/><br/><br/><br/><br/><br/><br/>
    <!-- Main form -->
   <div class="container">
            <form class="form-horizontal" role="form" action="auth.php" method="post">
                <h2>Login Form</h2>
               
                <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-9">
                        <input type="email" id="email" name="username" placeholder="Email" class="form-control" 
                        value="<?php
                        if (isset($_SESSION ['username'])) 
                        {
                          echo $_SESSION ['username'];
                          unset($_SESSION['username']);
                        }
                        ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                        <input type="password" id="password" name="password" placeholder="Password" class="form-control">
                    </div>
                </div>
               <!-- <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <label>
                                <a href="#">Forget Password</a>
                            </label>
                    </div>
                </div>  -->
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" name="submit" class="btn btn-primary btn-block">Login</button>
                    </div>
                </div>
                <?php
                 if (isset ($_SESSION['msg'])) 
                 {
                   echo "<p class='error'>" .$_SESSION ['msg']. "</p>";
                   unset ($_SESSION['msg']);
                 }
                ?>
               
            </form> <!-- /form -->
        </div> <!-- ./container -->

    </div> <!-- /container -->
       <br/><br/><br/><br/><hr>
<?php include 'footer.php'; ?>
   

    
  </body>
</html>