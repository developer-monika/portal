<?php
include('db.php');
if (! isset ($_SESSION ['is_user_logged_in'])) 
{
  header("location:login.php");
}

$a= $_POST['fullname'];
$d= $_POST['contact'];
$e= $_POST['city'];
$f= $_POST['gender'];
$id= $_SESSION ['id'];



$que="UPDATE info_tbl SET fullname='$a',contact='$d',city='$e',gender='$f'
WHERE id=$id";

mysql_query($que);
header("location:user_profile.php");
?>