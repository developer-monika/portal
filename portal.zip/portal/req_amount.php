<?php 
include 'db.php';
if (! isset ( $_SESSION ['is_user_logged_in'] ))
{
    header('location:login.php');
}
include("user_header.php");
?>

<div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <?php include 'sidebar.php'; ?>
         </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
           <h2 class="sub-header">Section title</h2>
                      <form class="form-horizontal" role="form" action="save_request.php" method="post">
                <h2>Registration Form</h2>
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Request Ammount</label>
                    <div class="col-sm-9">
                        <input type="text" id="" name="v_ammount" placeholder="enter ammount" class="form-control" autofocus>
                        
                    </div>
                </div>
                <div class="form-group">
                    <label for="message" class="col-sm-3 control-label">Remark</label>
                    <div class="col-sm-9">
                        <textarea type="" id="" cols="5" rows="6" name="v_remark" placeholder="type your message here" class="form-control">
                        </textarea>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" name="submit" class="btn btn-primary btn-block">Request</button>
                    </div>
                </div>
                </form>
              
        </div>
      </div>
    </div>
     <?php include 'footer.php';?>
    
  
   

    
  </body>
</html>