<?php include 'user_header.php';
include("db.php");
if(! isset($_SESSION['is_user_logged_in']))
{
  header("location:login.php");
}
include("user_header.php");
$que="SELECT * FROM request_ammount_tbl WHERE status=1 AND user_id=".$_SESSION['id'];
$obj=mysql_query($que);

?>

<div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
           <?php include 'sidebar.php'; ?>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
         <h2>My account</h2>
         <table width="90%" border="1" align="center">
        <tr>
          <th>Date</th>
          <th>Perticulers</th>
          <th>Credit Amount</th>
          <th>Debit Amount</th>
          <th>Remaining Balance</th>
        </tr>
      <?php
      $cr_amount=0;
      while($data=mysql_fetch_assoc($obj))
      {
        echo "<Tr>";
        $arr=explode(" ", $data['c_date']);
        $arr2=explode("-", $arr[0]);
        echo "<td>".$arr2[2]."-".$arr2[1]."-".$arr2[0]."</td>";
        echo "<td>".$data['remark']."</td>";
        if($data['trans_type']==1)
        {
          $cr_amount+=$data['amount'];
          echo "<td>".$data['amount']."</td>";
          echo "<td></td>";
        }
        if($data['trans_type']==2)
        {
          $cr_amount-=$data['amount'];
          echo "<td></td>";

          echo "<td>".$data['amount']."</td>";

        }
        echo "<td>".$cr_amount."</td>";
        echo "</tr>";
      }
      ?>
      </table>
         </h2>
       
        </div>
      </div>
    </div>
     <?php include 'footer.php';?>
    
  
   

    
  </body>
</html>