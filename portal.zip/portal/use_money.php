<?php 
include 'header.php';
include 'db.php';
if (! isset ( $_SESSION ['is_user_logged_in'] ))
{
    header('location:login.php');
}
include("user_header.php");

$id=$_SESSION['id'];
$que="SELECT balance FROM info_tbl WHERE id=$id";
$obj= mysql_query($que);
$data=mysql_fetch_assoc($obj);
//print_r($data);
?>
<div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <?php include 'sidebar.php'; ?>
         </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
           <h2 class="sub-header">Use your ammount <?php
     echo $data ['balance'];
            ?></h2>
          <form class="form-horizontal" role="form" action="save_money.php" method="post">
                   <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Ammount</label>
                    <div class="col-sm-9">
                        <input type="text" id="" name="amount" placeholder="enter ammount" class="form-control" autofocus>
                        
                    </div>
                </div>
                <div class="form-group">
                    <label for="message" class="col-sm-3 control-label">Purpose</label>
                    <div class="col-sm-9">
                  <select name="purpose">
                  <option>Select</option>
            <option>Shopping</option>
            <option>Recharge</option>
            <option>Payment</option>
            </select>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" name="submit" class="btn btn-primary btn-block">Request</button>
                    </div>
                </div>
                </form>
               
        </div>
      </div>
    </div>
     <?php include 'footer.php';?>
    
  
   

    
  </body>
</html>