-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 31, 2017 at 05:32 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE IF NOT EXISTS `admin_tbl` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`username`, `password`) VALUES
('admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `info_tbl`
--

CREATE TABLE IF NOT EXISTS `info_tbl` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `account_no` int(255) NOT NULL,
  `balance` int(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `info_tbl`
--

INSERT INTO `info_tbl` (`id`, `fullname`, `email`, `account_no`, `balance`, `password`, `contact`, `city`, `gender`, `image_name`) VALUES
(1, 'monika', 'm@gmail.com', 100001, 1000, '6512bd43d9caa6e02c990b0a82652dca', '1234567890', 'Bhopal', 'Female', '');

-- --------------------------------------------------------

--
-- Table structure for table `request_ammount_tbl`
--

CREATE TABLE IF NOT EXISTS `request_ammount_tbl` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `user_id` int(255) NOT NULL,
  `amount` int(255) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `c_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0',
  `trans_type` int(255) NOT NULL DEFAULT '1' COMMENT '1 for credit and 2 for debit',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `request_ammount_tbl`
--

INSERT INTO `request_ammount_tbl` (`id`, `user_id`, `amount`, `remark`, `c_date`, `status`, `trans_type`) VALUES
(1, 3, 30000, '             dfbgfb           ', '2017-01-21 11:02:42', 0, 0),
(2, 10, 12345, '            for test            ', '2017-01-21 11:05:37', 0, 0),
(3, 11, 500000, '          jfierhjgtirjhgio              ', '2017-01-23 03:15:43', 0, 0),
(4, 3, 111111111, '             for dress           ', '2017-01-23 09:10:28', 0, 0),
(5, 3, 699999, '          jhuhilk              ', '2017-01-25 09:19:05', 0, 0),
(6, 1, 500000, '               for bank         ', '2017-01-27 08:50:51', 0, 0),
(7, 1, 0, '                        ghmgh,', '2017-01-27 09:31:09', 0, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
