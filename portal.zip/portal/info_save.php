<?php
include("db.php");
// print_r($_POST);
// die;
$con=@mysql_connect("localhost", "root","");
@mysql_select_db("portal", $con);
session_start();
$a = $_POST['fullname'];
$b = $_POST['email'];
$c = $_POST['password'];
$c=md5($c);
$d = $_POST['contact'];
$e = $_POST['city'];
$f = $_POST['gender'];
$g = $_POST['balance'];
if ($g=="") {
	$g=1000;
}


$que="INSERT INTO info_tbl (fullname,email,password,contact,city,gender,balance) 
          VALUES ('$a', '$b','$c','$d','$e','$f','$g')";
mysql_query($que);
$id =mysql_insert_id();
$account_no="10000".$id;
$que = "UPDATE info_tbl SET account_no=$account_no WHERE id=$id";
mysql_query($que);
$que="INSERT INTO request_ammount_tbl (user_id, amount, remark, status, trans_type) VALUES ($id, $g, 'opening balance', 1, 1)";
mysql_query($que);

header("location:login.php");
?>
	
