<?php
include("db.php");
$a=$_POST['v_ammount'];
$b=$_POST['v_remark'];
$id=$_SESSION['id'];
//print_r($_POST);
//die;

$que ="INSERT INTO request_ammount_tbl (user_id,amount,remark) VALUES('$id','$a','$b')";

mysql_query($que);
$_SESSION['msg']="your request has been added";
header("location:dashboard.php");
?>