<ul class="nav nav-sidebar">
            <li class="active"><a href="overview.php">Overview <span class="sr-only">(current)</span></a></li>
             <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="user_profile.php">My Profile</a></li>
            <li><a href="edit_profile.php">Edit Profile</a></li>
            <li><a href="uplod_profile.php">Uplod Profile</a></li>
            <li><a href="change_pass.php">Change Password</a></li>
            <li><a href="my_account.php">My Account</a></li>
            <li><a href="req_amount.php">Request Ammount</a></li>
            <li><a href="use_money.php">Use Money</a></li>
            <li><a href="login.php">Logout</a></li>
          </ul>