<?php
include("../db.php");
if(! isset($_SESSION['is_admin_logged_in']))
{
	header("location:../index.php");
}
$v_id=$_GET['id'];
$obj=mysql_query("SELECT * FROM request_ammount_tbl WHERE id=$v_id");
$data=mysql_fetch_assoc($obj);

$req_amount= $data['amount'];
$user_id=$data['user_id'];


mysql_query("UPDATE info_tbl SET balance=balance+$req_amount WHERE id=$user_id");
mysql_query("UPDATE request_ammount_tbl SET status=1 WHERE id=$v_id");
header("location:view_pending_req.php");
?>