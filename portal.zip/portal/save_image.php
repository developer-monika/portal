<?php
include("db.php");
if(! isset($_SESSION['is_user_logged_in']))
{
	header("location:login.php");
}
// print_r($_FILES);
$name=$_FILES['v_image']['name'];
$tmp_name=$_FILES['v_image']['tmp_name'];
$size=$_FILES['v_image']['size'];
$arr=explode(".", $name);
$ext=end($arr);
$max_size=1024*1024*2;
$new_name=rand(10000, 100000).$_SESSION['account_no'].".".$ext;
if($ext=="jpg" OR $ext=="jpeg" || $ext=="png" || $ext=="gif")
{
	if($size<=$max_size)
	{
		move_uploaded_file($tmp_name, "upload_img/".$new_name);
		mysql_query("UPDATE info_tbl SET image_name='$new_name' WHERE id=".$_SESSION['id']);
		header("location:user_profile.php");
	}
	else
	{
		$_SESSION['msg']="File Size too large";
		header("location:uplod_profile.php");
	}
}
else
{
	$_SESSION['msg']="File Type not allowed";
	header("location:uplod_profile.php");
}
// print_r($arr);
?>