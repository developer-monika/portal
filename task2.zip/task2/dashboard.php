<?php 
session_start();
if (isset($_SESSION["member_id"]) && $_SESSION["member_id"] != "") { ?>
	<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<a href="logout.php">Logout</a>

	<h1>Welcome to dashboard</h1>
</body>
</html>
	<?php }elseif(isset($_COOKIE['member_login']) && $_COOKIE['member_login'] !='') { ?>
		<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<a href="logout.php">Logout</a>

	<h1>Welcome to dashboard</h1>
</body>
</html>
	<?php }else{
		header("Location:index.php");
	}

	
	
	?>
