<?php
$con=mysql_connect("localhost","root","");
mysql_select_db("epolitics",$con);
$get_all_data=mysql_query("SELECT * FROM statelist");
$start=0;
$n=1;
if (isset($_GET['pageno'])) 
{
	$start=$_GET['pageno']-1;
	$start=$start*50;
	$n=$start+1;
}
$total_rows=mysql_num_rows($get_all_data);
$show_records_per_page=50;
$pages_shows=ceil($total_rows/$show_records_per_page);
$que="SELECT * FROM statelist LIMIT $start, $show_records_per_page";
$all_data=mysql_query($que);

?>

<!DOCTYPE html>
<html>
<head>
	<title>Pagination</title>
	<style type="text/css">
		.pegi{
			text-decoration: none;
			display: inline-block;
			border:1px solid #CCC;
			padding: 5px;
			color: #999;
			margin: 3px;
		

		}
	</style>
</head>
<body>
<center>
	<h1>Pagination</h1>
	<hr>
	<?php
	for ($i=1; $i<=$pages_shows; $i++) { 
		echo "<a href='pegination.php?pageno=".$i."' class='pegi'>".$i."</a>";
	}
	?>
</center>
<table align="center" border="1" width="500">
	<tr>
		<td>#</td>
		<td>City</td>
		<td>State</td>
	</tr>
   <?php
   while ($data=mysql_fetch_assoc($get_all_data)) 
   {
   echo "<tr>";
   echo "<td>".$n."</td>";
   echo "<td>".$data['city_name']."</td>";
   echo "<td>".$data['state']."</td>";
   echo "</tr>";
   $n++;
   }
   ?>
</table>
</body>
</html>