<?php
$con=mysql_connect("localhost","root","");
mysql_select_db("epolitics", $con);
$obj=mysql_query("SELECT * FROM statelist");

$start=0;
$n=1;
if (isset($_GET['pageno'])) 
{
    $start=$_GET['pageno']-1;
    $start=$start*50;
    $n=$start+1;	
}
$total_rows=mysql_num_rows($obj);
$show_records_per_page=50;
$pages_shows=ceil($total_rows/$show_total_records_per_page);
$que="SELECT * FROM statelist LIMIT $start, $show_records_per_page";
$onj=mysql_query($que);
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.pagination{
			text-decoration: none;
			display: inline-block;
			border:1px solid #CCC;
			padding: 5px;
			color: #999;
			margin: 3px;
		}
	</style>
</head>
<body>
<center>
<h5>Pagination</h5>
	<a href="#">&laquo;</a>
	<?php
	?>
	<a href="#">&raquo;</a>
</center>
<table align="center" border="1" width="500">
	  <tr>
	  	<td>#</td>
	  	<td>City Name</td>
	  	<td>State Name</td>
	  </tr>
	  <?php
	  while ($data=mysql_fetch_assoc($obj)) {
	  	echo "<tr>";
	  	echo "<td>".$n."</td>";
	  echo "<td>".$data['city_name']."</td>";
      echo "<td>".$data['state']."</td>";
      echo "</tr>";
      $n++;
	  }
	  ?>
</table>
</body>
</html>