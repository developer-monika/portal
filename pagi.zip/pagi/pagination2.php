<?php
$con=mysql_connect("localhost","root","");
mysql_select_db("epolitics",$con);
$get_list=mysql_query("SELECT * FROM statelist");
$start=0;
$n=1;
if (isset($_GET['paheno'])) 
{
	$start=$_GET['pageno']-1;
	$start=$start*50;
	$n=$start+1;
}
$total_rows=mysql_num_rows($get_list);
$show_records_per_page=50;
$pages_show=ceil($total_rows/$show_records_per_page);

$query="SELECT * FROM LIMIT $start, $show_records_per_page";
$object=mysql_query($query)
?>
<!DOCTYPE html>
<html>
<head>
	<title>Paginationnnnnn</title>
	<style type="text/css">
		.pagi{
	    display:inline-block;
		text-decoration:none;
		border: 1px solid black;
		padding: 5px;
		color: #ddd;
		margin: 3px;
				
		}
	</style>
</head>
<body>
<center><h1>Pagination Test</h1>
<hr>
<?php
for ($i=1; $i<=$pages_show; $i++) 
{ 
	echo "<a href='pagination2.php?pageno=".$i."' class='pagi'>".$i."</a>";
}
?>
</center>
<table width="500" align="center" border="1">
	<tr>
		<td>#</td>
		<td>City</td>
		<td>State</td>
	</tr>
	<?php
	while ($data=mysql_fetch_assoc($get_list)) 
	{
	echo "<tr>";
	echo "<td>".$n."</td>";
	echo "<td>".$data["city_name"]."</td>";
	echo "<td>".$data["state"]."<td>";
	echo "</tr>";
		$n++;
	}
	?>
</table>
</body>
</html>