<?php
$con=mysql_connect("localhost","root","");
mysql_select_db("epolitics",$con);
$obj=mysql_query("SELECT * FROM statelist");
$n=1;

?>
<!DOCTYPE html>
<html>
<head>
	<title>Pagi....</title>
</head>
<body>
<center>Pagination</center>
<table align="center" width="500" border="1">
	<tr>
		<td>#</td>
		<td>State</td>
		<td>City</td>
	</tr>
	<?php
	while ($data=mysql_fetch_assoc($obj)) 
	{
		echo "<tr>";
		echo "<td>".$n."</td>";
		echo "<td>".$data["state"]."</td>";
		echo "<td>".$data["city_name"]."</td>";
		echo "</tr>";
		$n++;
	}
	?>
</table>
</body>
</html>