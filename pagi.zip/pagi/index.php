<?php
$con=mysql_connect("localhost", "root", "");
mysql_select_db("epolitics", $con);
$obj=mysql_query("SELECT * FROM statelist");
// $total_rows=mysql_num_rows($obj);
$start=0;
$n=1;
if(isset($_GET['pageno']))
{

	$start=$_GET['pageno']-1;
	$start=$start*50;
	$n=$start+1;
}
else{
  // echo "string";
}
$total_rows=mysql_num_rows($obj);
$show_records_per_page=50;
$pages_shows=ceil($total_rows/$show_records_per_page);
$que="SELECT * FROM statelist LIMIT $start, $show_records_per_page";
$obj=mysql_query($que);
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.pagination{
			text-decoration: none;
			display: inline-block;
			border:1px solid #CCC;
			padding: 5px;
			color: #999;
			margin: 3px;
		}
	</style>
</head>
<body>
<center><h2>Sample Pagination</h2></center>
<Hr />
<center>
<?php
if(isset($_GET['pageno']))
{
	if($_GET['pageno'] != 1)
		{?>

		<a href="index.php?pageno=<?php echo $_GET['pageno']-1; ?>" class="pagination">&laquo;</a>

<?php }
	}
?>

<?php

for($i=1; $i<=$pages_shows; $i++)
{
	echo "<a href='index.php?pageno=".$i."' class='pagination'>".$i."</a>";
}
?>
<?php
if(isset($_GET['pageno']))
{
	if($_GET['pageno']!=$pages_shows)
		{?>
<a href="index.php?pageno=<?php echo $_GET['pageno']+1; ?>" class="pagination">&raquo;</a>

<?php }
}
?>
</center>
<table align="center" border="1" width="500">
	<tr>
		<th>#</th>
		<th>City Name</th>
		<th>State Name</th>
	</tr>
	<?php
	
	while($data=mysql_fetch_assoc($obj))
	{
		echo "<tr>";
		echo "<td>".$n."</td>";
		echo "<td>".$data['city_name']."</td>";
		echo "<td>".$data['state']."</td>";
		echo "</tr>";
		$n++;
	}
	?>
	
</table>
</body>
</html>